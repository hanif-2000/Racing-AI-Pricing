from django.apps import AppConfig


class RacingConfig(AppConfig):
    name = 'racing'
